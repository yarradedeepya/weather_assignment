# diagram/__init__.py
from .diagram_generator import create_html_diagram, generate_diagram
