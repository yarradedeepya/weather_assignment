# weather_api/__init__.py
from .api import get_weather
